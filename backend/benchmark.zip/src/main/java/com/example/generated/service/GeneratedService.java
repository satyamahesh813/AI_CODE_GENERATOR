package com.example.generated.service;

import org.springframework.stereotype.Service;

@Service
public class GeneratedService {
    // LLM Generated Logic
public void generatedMethod() {
    System.out.println("Hello from LLM");
}
}
